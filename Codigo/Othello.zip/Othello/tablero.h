#ifndef TABLERO_H
#define TABLERO_H
#include <iostream>

using namespace std;

class tablero {
private:
    char **matrizTablero;

public:
    tablero();
    ~tablero();

    char **memoriaDinamicaTablero();
    void inicializarTablero();
    void imprimirTablero();
};

#endif // TABLERO_H

