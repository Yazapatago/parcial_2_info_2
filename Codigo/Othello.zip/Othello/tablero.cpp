#include "tablero.h"
#include <iostream>

tablero::tablero() {//el constructor realiza la asignacion de la memoria dinamica del tablero y me inicializa el tablero
    matrizTablero = memoriaDinamicaTablero();
    inicializarTablero();
}

tablero::~tablero() {//libera la memoria dinamica
    for (int i = 0; i < 8; i++) {
        delete[] matrizTablero[i];
    }
    delete[] matrizTablero;
}

char **tablero::memoriaDinamicaTablero() {//metodo que asigna la memoria dinamica de la matriz del tablero
    char **matrizTablero = new char *[8];
    for (int i = 0; i < 8; i++) {
        matrizTablero[i] = new char[8];
    }
    return matrizTablero;
}

void tablero::inicializarTablero() {//metodo que inicializa la matriz 8x8 que es el tablero
    for (int fil = 0; fil < 8; fil++) {
        for (int col = 0; col < 8; col++) {
            matrizTablero[fil][col] = '.';
        }
    }
}

void tablero::imprimirTablero() {//imprime la matriz 8x8 que es el tablero
    for (int fil = 0; fil < 8; fil++) {
        for (int col = 0; col < 8; col++) {
            cout << matrizTablero[fil][col] << "\t";
        }
        cout << endl;
    }
}
