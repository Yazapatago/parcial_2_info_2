#include "tablero.h"

int main() {

    tablero miTablero;

    miTablero.imprimirTablero();

    return 0;
}
